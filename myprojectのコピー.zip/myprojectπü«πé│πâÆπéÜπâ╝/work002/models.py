from django.db import models

class Entry(models.Model):
    CATEGORY_CHOICES = [
        ("income", "収入"),
        ("expense", "支出"),
    ]
    date = models.DateField()
    category = models.CharField(max_length=10, choices=CATEGORY_CHOICES)
    description = models.CharField(max_length=200, blank=True)
    amount = models.IntegerField()

    def __str__(self):
        return f"{self.date} {self.get_category_display()} {self.amount}円 {self.description}"

    @property
    def formatted_amount(self):
        # 桁区切りで返す
        return f"{self.amount:,}円"
