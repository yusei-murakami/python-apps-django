from django.shortcuts import render, redirect, get_object_or_404
from .models import Entry
from .forms import EntryForm

def entry_list(request):
    entries = Entry.objects.all().order_by("-date")

    total_income = sum(e.amount for e in entries if e.category == "income")
    total_expense = sum(e.amount for e in entries if e.category == "expense")
    balance = total_income - total_expense

    return render(request, "work002/entry_list.html", {
        "entries": entries,
        "total_income": total_income,
        "total_expense": total_expense,
        "balance": balance,
    })

def entry_create(request):
    if request.method == "POST":
        form = EntryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("work002:entry_list")
    else:
        form = EntryForm()
    return render(request, "work002/entry_form.html", {"form": form})

def entry_update(request, pk):
    entry = get_object_or_404(Entry, pk=pk)
    if request.method == "POST":
        form = EntryForm(request.POST, instance=entry)
        if form.is_valid():
            form.save()
            return redirect("work002:entry_list")
    else:
        form = EntryForm(instance=entry)
    return render(request, "work002/entry_form.html", {"form": form})

def entry_delete(request, pk):
    entry = get_object_or_404(Entry, pk=pk)
    if request.method == "POST":
        entry.delete()
        return redirect("work002:entry_list")
    return render(request, "work002/entry_confirm_delete.html", {"entry": entry})
