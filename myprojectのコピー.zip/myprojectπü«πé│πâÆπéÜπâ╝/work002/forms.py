from django import forms
from .models import Entry

class EntryForm(forms.ModelForm):
    PRESET_CHOICES = [
        ("食費", "食費"),
        ("交通費", "交通費"),
        ("給料", "給料"),
        ("娯楽", "娯楽"),
        ("その他", "その他"),
    ]

    preset_description = forms.ChoiceField(
        choices=[("", "選択してください")] + PRESET_CHOICES,
        required=False,
        label="内容（選択肢）"
    )
    custom_description = forms.CharField(
        required=False,
        label="内容（自由入力）",
        widget=forms.TextInput(attrs={'placeholder': '例: 書籍代, ボーナスなど'})
    )

    class Meta:
        model = Entry
        fields = ['date', 'category', 'preset_description', 'custom_description', 'amount']
        labels = {
            'date': '日付',
            'category': '収支区分',
            'amount': '金額',
        }
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'amount': forms.NumberInput(attrs={'placeholder': '金額を入力'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        preset = cleaned_data.get("preset_description")
        custom = cleaned_data.get("custom_description")

        # 両方空ならエラー
        if not preset and not custom:
            raise forms.ValidationError("内容は選択または自由入力してください。")

        # description にまとめる
        cleaned_data["description"] = custom if custom else preset
        return cleaned_data
